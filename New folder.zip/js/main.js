
var app = angular.module('mainApp', [
  'ngRoute',
  'mainApp.config',
  'mainApp.controller',
  'mainApp.service',
  'ngSanitize'
]);

/*
 * Configure the Routes
 */
app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    
    .when("/", {templateUrl: "partials/home.html", controller: "HomeCtrl"})
    //Available Pages
    .when("/page1", {templateUrl: "partials/page1.html", controller: "Page1Ctrl"})
    .when("/page2", {templateUrl: "partials/page2.html", controller: "Page2Ctrl"})
    .when("/page3", {templateUrl: "partials/page3.html", controller: "Page3Ctrl"})
    .when("/page4", {templateUrl: "partials/page4.html", controller: "Page4Ctrl"})
	.when("/page5", {templateUrl: "partials/page5.html", controller: "Page5Ctrl"})
	.when("/page6", {templateUrl: "partials/page6.html", controller: "Page6Ctrl"})
   
    // Else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
}]);
