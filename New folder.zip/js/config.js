
/*
 * Main AngularJS Web Application
 */
var app = angular.module('mainApp.config', []).constant('FILE_PAH','./data/');



