/*
 * Main AngularJS Web Application
 */
var app = angular.module('mainApp.service', [
 
]);

/*
 * Angular JS Services
 */
 app.service('BasicService', function ($http,$q,$log) {
            
			/* this.getlanguage = function()
			{
				if(language === 'eng'){
					  lang = 'eng';
					  fileName = 'home_page_eng';
				  }else if(language ==='chs'){
					  lang = 'chs';
					  fileName = 'home_page_chs';
				  }else{
					  lang = 'eng';
					  fileName = 'home_page_eng';
				  }
			} */
			
			this.xmlParsing = function (fileName,language){
		    var deferred = $q.defer();
			$http({
				method  : 'GET',
				url     : 'data/xml/'+language+'/'+fileName+'.xml',
				params  : {}, 
				
			}).success(function(response, status, headers, config) {
				        var x2js = new X2JS();
                        var res = x2js.xml_str2json(response);
                        deferred.resolve(res);
						
			
            }).error(function(response, status, headers, config) {
						deferred.reject(response);
						$log.error(response, code);

			});
			return deferred.promise;
			};
			this.locality = function(language){
				
			}
 });