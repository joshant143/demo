var app = angular.module('mainApp.controller', ['mainApp.config']);
app.constant('RESOURCES', (function() {
	var selectLang = sessionStorage.getItem("SelectedLanguage");
	if(selectLang == null && selectLang =="null"){
		selectLang = 'eng';
		
	}
    return {
        FILE_PATH: '/data',
        LANGUAGE_NAME: selectLang,
    }
})());
/*
 * Controls the Home page
 */
app.controller('HomeCtrl', function($scope, $location, $http, RESOURCES, BasicService) {
    console.log("Home Controller Loaded...");
    $scope.language = 'eng';   
	var language = 'eng';
	var fileName = 'index_eng';
	getLangJSON(fileName,language);
	
    /* $scope.init = function() {
        getLangJSON(fileName,language);
    }; */
    

    function getLangJSON(fileName,lang) {
        var xmlParseObj = BasicService.xmlParsing(fileName, lang);
        xmlParseObj.then(function(data) {
            console.log(data);
            $scope.response = data;
        });
    };
	
	$scope.changeLanguage = function(){
    chkbrowser();
	  RESOURCES.LANGUAGE_NAME = $scope.language;
	  sessionStorage.setItem("SelectedLanguage",$scope.language);
	  console.log('ResourceLang' + RESOURCES.LANGUAGE_NAME);
	  var language = $scope.language;
	  var fileName = 'index_'+ $scope.language;
	  getLangJSON(fileName,language);
	  $('.select > option:first-child').css('visibility','visible')
  };

  // Detecting the browser
  function chkbrowser() { 
      
    if((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1 ) 
   {
       alert('Opera');
   }
   else if(navigator.userAgent.indexOf("Chrome") != -1 )
   {
       alert('Chrome');
   }
   else if(navigator.userAgent.indexOf("Safari") != -1)
   {
       alert('Safari');
   }
   else if(navigator.userAgent.indexOf("Firefox") != -1 ) 
   {
        alert('Firefox');
   }
   else if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
   {
     alert('IE'); 
   }  
   else 
   {
      alert('unknown');
   }
   }
});

/*
* Controls all other Pages
  Page1 Controller
*/
app.controller('Page1Ctrl', function($scope, $location, $http, BasicService, RESOURCES) {
    console.log("Page1 Controller Loaded...");
	
    $scope.init = function() {
        var language = RESOURCES.LANGUAGE_NAME;
		var fileName = 'page1_'+language;
        getLangJSON(fileName, language);
    };
    $scope.init();

	// Next Button Click
  $scope.nextPage = function(){
    $location.path('/page3');
  };
  
  
    function getLangJSON(fileName, lang) {
        var xmlParseObj = BasicService.xmlParsing(fileName, lang);
        xmlParseObj.then(function(data) {
            console.log(data);
            $scope.response = data;
        });
    };

});
/*
 * Page2 Controller
 */
app.controller('Page2Ctrl', function($scope, $location, $http, BasicService, RESOURCES) {
    console.log("Page2 Controller Loaded...");

	$scope.init = function() {
        var language = RESOURCES.LANGUAGE_NAME;
		var fileName = 'page2_'+language;
        getLangJSON(fileName, language);
    };
    $scope.init();

	// Next Button Click
  $scope.nextPage = function(){
    $location.path('/page3');
  };
  // Previous Button Click
   $scope.previousPage = function(){
    $location.path('/page1'); 
  };
  
    function getLangJSON(fileName, lang) {
        var xmlParseObj = BasicService.xmlParsing(fileName, lang);
        xmlParseObj.then(function(data) {
            console.log(data);
            $scope.response = data;
        });
    };

});
/*
 * Page3 Controller 
 */
app.controller('Page3Ctrl', function($scope, $location, $http, BasicService, RESOURCES) {
    console.log("Page3 Controller Loaded...");
	
	$scope.init = function() {
        var language = RESOURCES.LANGUAGE_NAME;
		var fileName = 'page3_'+language;
        getLangJSON(fileName, language);
    };
    $scope.init();

	// Next Button Click
  $scope.nextPage = function(){
    $location.path('/page4');
  };
  // Previous Button Click
   $scope.previousPage = function(){
    $location.path('/page2'); 
  };
  
    function getLangJSON(fileName, lang) {
        var xmlParseObj = BasicService.xmlParsing(fileName, lang);
        xmlParseObj.then(function(data) {
            console.log(data);
            $scope.response = data;
        });
    };
});
/*
 * Page4 Controller
 */
app.controller('Page4Ctrl', function($scope, $location, $http, BasicService, RESOURCES) {
    console.log("Page4 Controller Loaded...");
	
	$scope.init = function() {
        var language = RESOURCES.LANGUAGE_NAME;
		var fileName = 'page4_'+language;
        getLangJSON(fileName, language);
    };
    $scope.init();
	
	// Next Button Click
  $scope.nextPage = function(){
    $location.path('/page5');
  };
  // Previous Button Click
   $scope.previousPage = function(){
    $location.path('/page3'); 
  };
    function getLangJSON(fileName, lang) {
        var xmlParseObj = BasicService.xmlParsing(fileName, lang);
        xmlParseObj.then(function(data) {
            console.log(data);
            $scope.response = data;
        });
    };

});
/*
 * Page5 Controller
 */
app.controller('Page5Ctrl', function($scope, $location, $http, BasicService, RESOURCES) {
    console.log("Page5 Controller Loaded...");
	
	$scope.init = function() {
        var language = RESOURCES.LANGUAGE_NAME;
		var fileName = 'page5_'+language;
        getLangJSON(fileName, language);
    };
    $scope.init();
	
	// Next Button Click
	  $scope.nextPage = function(){
		$location.path('/page6');
	  };
	  // Previous Button Click
	   $scope.previousPage = function(){
		$location.path('/page4'); 
	  };
    function getLangJSON(fileName, lang) {
        var xmlParseObj = BasicService.xmlParsing(fileName, lang);
        xmlParseObj.then(function(data) {
            console.log(data);
            $scope.response = data;
        });
    };

});

/*
 * Page6 Controller
 */
app.controller('Page6Ctrl', function($scope, $location, $http, BasicService, RESOURCES) {
    console.log("Page6 Controller Loaded...");
	
	$scope.init = function() {
        var language = RESOURCES.LANGUAGE_NAME;
		var fileName = 'page6_'+language;
        getLangJSON(fileName, language);
    };
    $scope.init();
// Next Button Click
  /* $scope.nextPage = function(){
    $location.path('/page3');
  }; */
  // Previous Button Click
   $scope.previousPage = function(){
    $location.path('/page5'); 
  };
    function getLangJSON(fileName, lang) {
        var xmlParseObj = BasicService.xmlParsing(fileName, lang);
        xmlParseObj.then(function(data) {
            console.log(data);
            $scope.response = data;
        });
    };

});

/*
 *  Common Function
 */